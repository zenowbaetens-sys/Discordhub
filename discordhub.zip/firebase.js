// Firebase configuratie
// Deze gegevens krijg je van Firebase Console

const firebaseConfig = {

apiKey: "JOUW_API_KEY",

authDomain: "JOUW_PROJECT.firebaseapp.com",

projectId: "JOUW_PROJECT_ID",

storageBucket: "JOUW_PROJECT.appspot.com",

messagingSenderId: "JOUW_SENDER_ID",

appId: "JOUW_APP_ID"

};


firebase.initializeApp(firebaseConfig);


const db = firebase.firestore();

const auth = firebase.auth();